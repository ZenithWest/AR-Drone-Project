#ifndef _UVLC_MB_LAYER_P5P_H_
#define _UVLC_MB_LAYER_P5P_H_

#include <VLIB/UVLC/uvlc.h>

void uvlc_write_block( video_stream_t* const stream, int16_t* data, int32_t num_coeff );

#endif // _UVLC_MB_LAYER_P5P_H_
