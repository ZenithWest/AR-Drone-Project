#ifndef _VIDEO_UTILS_X86_H_
#define _VIDEO_UTILS_X86_H_

#if TARGET_CPU_X86 == 1

#include <intrin.h>

#include "video_utils_x86.h"

#endif // TARGET_CPU_X86 == 1

#endif // _VIDEO_UTILS_X86__H_
