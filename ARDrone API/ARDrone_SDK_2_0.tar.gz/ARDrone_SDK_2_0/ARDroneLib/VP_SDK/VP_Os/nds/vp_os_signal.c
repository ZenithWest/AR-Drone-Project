/**
 * @file signal.c
 * @author aurelien.morelle@parrot.fr
 * @date 2006/12/15
 */

#include "VP_Os/vp_os_signal.h"


void
vp_os_mutex_init(vp_os_mutex_t *mutex)
{
}


void
vp_os_mutex_destroy(vp_os_mutex_t *mutex)
{
}


void
vp_os_mutex_lock(vp_os_mutex_t *mutex)
{
}


void
vp_os_mutex_unlock(vp_os_mutex_t *mutex)
{
}


void
vp_os_cond_init(vp_os_cond_t *cond, vp_os_mutex_t *mutex)
{
}


void
vp_os_cond_destroy(vp_os_cond_t *cond)
{
}


void
vp_os_cond_wait(vp_os_cond_t *cond)
{
}


void
vp_os_cond_signal(vp_os_cond_t *cond)
{
}

